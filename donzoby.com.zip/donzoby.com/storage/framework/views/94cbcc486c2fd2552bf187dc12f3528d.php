<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta property="og:image" content="<?php echo e(str_replace('https', 'http', $pageImage)); ?>" />
    <meta property="og:image:url" content="<?php echo e(str_replace('https', 'http', $pageImage)); ?>" />

    <title><?php echo e($title); ?></title>
    <meta name="description" content="<?php echo e($description); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />


    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/prism.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/line-number.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>">
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js', 'resources/sass/main.scss']); ?>
    <?php if($customStyle == 'single'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/single.scss']); ?>
        
    <?php elseif($customStyle == 'home'): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/home.scss']); ?>
        
    <?php endif; ?>

</head>

<body class="font-sans antialiased">
    <div class='tw-py-2 tw-px-4 tw-flex tw-justify-between'>
        <h1 style="font-size: 0.9em" class="float-left">Tech Tutorials for The Elects</h1>
        <div class="">
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(url('register')); ?>" class="float-right align-middle">Register</a>
                <a class="float-right" href="<?php echo e(url('login')); ?>">Login</a>
            <?php else: ?>
                <a href = "<?php echo e(url('user-area')); ?>" style="text-transform: uppercase;" class="float-right">
                    <?php echo e(Auth::user()->first_name); ?></a>
                <a class="float-right" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
            <?php endif; ?>
        </div>
    </div>
    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Page Content -->
    <main class="">
        <div class="container-fluid">
            <div class="row">
                <div x-data="showNav" class="left-nav col-12 col-sm-3 col-md-2">
                    <span x-show="isSmallScreen || showLatest" @click="toggleShowNav" class="sm:tw-hidden">
                        <i x-show="!showLatest" class="fa fa-bars" aria-hidden="true"></i>
                        <i x-show="showLatest" class="fa fa-times" aria-hidden="true"></i> All
                        Latest</span>
                    <section x-show="!isSmallScreen || showLatest" class=" ">
                        <?php if (isset($component)) { $__componentOriginal96d9c9f84c0ec969cc118ff7ae498bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal96d9c9f84c0ec969cc118ff7ae498bc9 = $attributes; } ?>
<?php $component = App\View\Components\LeftNav::resolve(['posts' => $posts,'listedSubjects' => $listedSubjects] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('left-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LeftNav::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal96d9c9f84c0ec969cc118ff7ae498bc9)): ?>
<?php $attributes = $__attributesOriginal96d9c9f84c0ec969cc118ff7ae498bc9; ?>
<?php unset($__attributesOriginal96d9c9f84c0ec969cc118ff7ae498bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96d9c9f84c0ec969cc118ff7ae498bc9)): ?>
<?php $component = $__componentOriginal96d9c9f84c0ec969cc118ff7ae498bc9; ?>
<?php unset($__componentOriginal96d9c9f84c0ec969cc118ff7ae498bc9); ?>
<?php endif; ?>
                    </section>
                    <script>
                        document.addEventListener('alpine:init', () => {
                            Alpine.data('showNav', () => ({
                                showLatest: false,
                                hasCheckedWidth: false,
                                isSmallScreen: false,

                                async init() {
                                    window.addEventListener('resize', function() {
                                        // Call the function to check window size
                                        checkWindowSize(window.innerWidth);
                                    });

                                    checkWindowSize = (width) => {
                                        if (width > 640) {
                                            this.showLatest = true;
                                            this.isSmallScreen = false;
                                        } else {
                                            this.showLatest = false;
                                            this.isSmallScreen = true;
                                        }
                                    }
                                    if (!this.hasCheckedWidth) {
                                        checkWindowSize(window.innerWidth);
                                        this.hasCheckedWidth = true;
                                    }
                                },

                                // GETTERS

                                // METHODS
                                toggleShowNav() {
                                    this.showLatest = !this.showLatest;
                                },
                            }));
                        });
                    </script>
                </div>
                <div class="col-12 col-sm-9 col-md-10 col-lg-7 line-numbers" style="font-family: Figtree">
                    <!-- <h1>Welcome to DTech where we do tech with conscience!</h1> -->
                    <?php echo e($slot); ?>


                </div>
                <div class="col-12 d-sm-none d-lg-block col-md-3 tw-pt-4">
                    <img src="<?php echo e(asset('images/dzb-tut-ad.png')); ?>" alt="possible error message to users">
                    <p class="tw-border tw-text-center tw-p-2 tw-border-dashed tw-border-stone-500">
                        Please notify us of
                        any error or
                        mistake. While we are
                        making efforts to be accurate and as concise as possible, we know that some errors can still
                        slip through uncaught.</p>
                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>


    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <script src="https://kit.fontawesome.com/b379d389cf.js" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/prism.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\dev\xampp\htdocs\donzoby.com\donzoby.com\resources\views/layouts/app.blade.php ENDPATH**/ ?>