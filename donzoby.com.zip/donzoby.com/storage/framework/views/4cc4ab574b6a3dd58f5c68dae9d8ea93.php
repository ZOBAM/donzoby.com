<footer id="footer" class=" tw-pt-8">
    <div class = 'container-fluid'>
        <div class='row'>
            <div class="col-sm-4">
                <h5>COMPANY INFO</h5>
                <a href="/about-donzoby">About Us<br /></a>
                <a href="/mission-&-vision">Mission & Vision<br /></a>
                <a href="">Career</a><br />
                <a href="/privacy-policy">Privacy Policy<br /></a>
                <a href="">Terms of Use</a><br />
            </div>
            <div class="col-sm-4">
                <h5>SOCIAL</h5>
                <a href="https://www.facebook.com/donzoby"><i class="fab fa-facebook-square"></i> Facebook</a> <br />
                <a href="#"><i class="fab fa-twitter-square"></i> Twitter</a>
            </div>
            <div class="col-sm-4">
                <h5>LEARN</h5>
                <a href="">Front-end</a><br />
                <a href="">Graphics</a><br />
                <a href="">Back-end</a><br />
                <a href="">Mobile Development</a><br />
            </div>
        </div>
    </div>
    <div class = 'container-fluid'>
        <div class="row" style="color:#EFF1EF;background-color: #3C3C3C">
            <div class='col-sm-12' style="color:#EFF1EF;background-color: #4D4D4D">CONTACT US:</div>
            <div class="col-sm-3">Email: info@donzoby.com</div>
            <div class="col-sm-6">Besides Bricks Estate, New Layout, Enugu State. </div>
            <div class="col-sm-3">Tel: 09057965147</div>
        </div>
    </div>
</footer>
<?php /**PATH C:\dev\xampp\htdocs\donzoby.com\donzoby.com\resources\views/components/footer.blade.php ENDPATH**/ ?>