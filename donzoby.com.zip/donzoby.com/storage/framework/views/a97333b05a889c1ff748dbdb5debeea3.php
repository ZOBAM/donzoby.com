<?php if (isset($component)) { $__componentOriginal951024bfcf58033c82ac11d797616473 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal951024bfcf58033c82ac11d797616473 = $attributes; } ?>
<?php $component = App\View\Components\UserLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UserLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <?php if(session()->has('post_delete_success')): ?>
        <div class="alert alert-success" role="alert">
            <h3> Post successfully deleted!</h3>
        </div>
    <?php endif; ?>
    <?php if(session()->has('post_delete_error')): ?>
        <div class="alert alert-danger" role="alert">
            <h3> <?php echo e(session('post_delete_error')); ?></h3>
        </div>
    <?php endif; ?>

    <h1 class="text-center">All Posts</h1>
    <?php if(count($posts) > 0): ?>
        <?php
        $pageNo = 0;
        if (isset($_GET['page'])) {
            $pageNo = $_GET['page'] - 1;
        }
        $nos = 1;
        ?>
        <div class="table-responsive">
            <table class="table">
                <?php ?> <!-- initiate no for numbering the list -->
                <tr>
                    <th colspan="7" class="text-center"><i class="fa fa-home" style="color: green"></i> List of your
                        written Posts<sup>(<?php echo e(count($posts)); ?>)</sup></th>
                </tr>

                <tr>
                    <th>S/N</th>
                    <th>Course</th>
                    <th>Subject</th>
                    <th>Topic</th>
                    <th>Post Content</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pageNo * 10 + $nos++); ?></td>
                        <td><?php echo e($post->subject->course->name); ?></td>
                        <td><?php echo e($post->subject->name); ?>

                            <br><a href="<?php echo e(url('post/' . $post->id)); ?>"> Preview <i class="fa fa-expand"></i></a>
                        </td>
                        <td>
                            <?php echo e($post->topic); ?>

                            <?php if($post->is_parent): ?>
                                <hr class="tw-mb-2">
                                <span class="tw-px-2 tw-py-1 tw-bg-gray-200 tw-rounded-md">Parent</span>
                            <?php endif; ?>
                            <?php if($post->is_child): ?>
                                <hr class="tw-mb-2">
                                <span class="tw-px-2 tw-py-[0.5] tw-border-2 tw-border-200 tw-rounded-md">Child</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $post->content; ?> </td>
                        <td><?php echo Str::words($post->description, '25'); ?><br> <i>Written
                                on:<?php echo e(date('M d, Y', strtotime($post->created_at))); ?></i></td>
                        <td>
                            <a href="<?php echo e(url('posts/' . $post->id . '/edit')); ?>"><i class="fa fa-edit"></i> Edit</a>
                            <form method="POST" action="<?php echo e(url('posts/' . $post->id)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <!-- <input type= "hidden" name="_method" value ="DELETE"> -->
                                <button
                                    onclick = 'return confirm("<?php echo e(Auth::user()->name); ?>, do you want to delete this Post? Click OK to delete or CANCEL to return")'>Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e($posts->links()); ?>

        </div>
    <?php else: ?>
        Your post will be listed here soon when you write posts.
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal951024bfcf58033c82ac11d797616473)): ?>
<?php $attributes = $__attributesOriginal951024bfcf58033c82ac11d797616473; ?>
<?php unset($__attributesOriginal951024bfcf58033c82ac11d797616473); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal951024bfcf58033c82ac11d797616473)): ?>
<?php $component = $__componentOriginal951024bfcf58033c82ac11d797616473; ?>
<?php unset($__componentOriginal951024bfcf58033c82ac11d797616473); ?>
<?php endif; ?>
<?php /**PATH C:\dev\xampp\htdocs\donzoby.com\donzoby.com\resources\views/admin/posts.blade.php ENDPATH**/ ?>