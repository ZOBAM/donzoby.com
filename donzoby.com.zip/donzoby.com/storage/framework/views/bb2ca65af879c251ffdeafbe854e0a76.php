<?php if(isset($posts)): ?>
    <?php $__currentLoopData = $listedSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($sub); ?></h3>
        <div class="">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($post->subject->name == $sub): ?>
                    <a
                        href="<?php echo e(url('/' . $post->subject->course->slug . '/' . $post->subject->slug . '/' . $post->slug)); ?>"><?php echo e($post->topic); ?></a>
                    <?php if(count($post->children)): ?>
                        <?php $__currentLoopData = $post->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="tw-ml-3" style="box-shadow: -2px 0px 1px rgb(200, 198, 218)"
                                href="<?php echo e(url('/' . $child_post->subject->course->slug . '/' . $child_post->subject->slug . '/' . $child_post->slug)); ?>"><?php echo e($child_post->topic); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\dev\xampp\htdocs\donzoby.com\donzoby.com\resources\views/components/left-nav.blade.php ENDPATH**/ ?>