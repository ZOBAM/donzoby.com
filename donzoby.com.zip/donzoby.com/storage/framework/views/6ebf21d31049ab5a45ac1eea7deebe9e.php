<?php if (isset($component)) { $__componentOriginal951024bfcf58033c82ac11d797616473 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal951024bfcf58033c82ac11d797616473 = $attributes; } ?>
<?php $component = App\View\Components\UserLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UserLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section x-data='users'>
        
        <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success" role="alert">
                <h3><?php echo e(session('success_message')); ?></h3>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error_message')): ?>
            <div class="alert alert-danger" role="alert">
                <h3> <?php echo e(session('error_message')); ?></h3>
            </div>
        <?php endif; ?>
        <h1 class="text-center">All Users</h1>
        <?php if(count($users) > 0): ?>
            <?php
            $pageNo = 0;
            if (isset($_GET['page'])) {
                $pageNo = $_GET['page'] - 1;
            }
            $nos = 1;
            ?>
            <div class="table-responsive">
                <table class="table">
                    <?php ?> <!-- initiate no for numbering the list -->
                    <tr>
                        <th colspan="7" class="text-center"><i class="fa fa-home" style="color: green"></i> List of all
                            users<sup>(<?php echo e($users->total()); ?>)</sup></th>
                    </tr>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Comment Count</th>
                        <th>Created On</th>
                        <th>Actions</th>
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pageNo * 10 + $nos++); ?></td>
                            <td>
                                <?php echo e($user->first_name . ' ' . $user->last_name); ?>

                            </td>
                            <td>
                                <?php echo e($user->email); ?> <br>
                                <?php if($user->email_verified_at): ?>
                                    <span class="badge text-bg-success">verified</span>
                                <?php else: ?>
                                    <span class="badge text-bg-secondary">unverified</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($user->status); ?>

                            </td>
                            <td><?php echo e($user->comments()->count()); ?> </td>
                            <td><i><?php echo e(date('M d, Y', strtotime($user->created_at))); ?></i></td>
                            <td>
                                <a class="" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button"
                                    aria-controls="offcanvasExample" @click="edit(<?php echo e($user->id); ?>)"><i
                                        class="fa fa-edit"></i> Edit</a>
                                <form method="POST" action="<?php echo e(url('admin/users/' . $user->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <!-- <input type= "hidden" name="_method" value ="DELETE"> -->
                                    <button
                                        onclick = 'return confirm("<?php echo e(Auth::user()->name); ?>, do you want to delete this User? Click OK to delete or CANCEL to return")'>Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($users->links()); ?>

            </div>
        <?php else: ?>
            Your users will be listed here soon when you have users.
        <?php endif; ?>
        <hr>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasExample"
            aria-labelledby="offcanvasExampleLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title tw-font-bold" id="offcanvasExampleLabel" x-text="userFullName"></h5>
                <button @click="reloadPage" type="button" class="btn-close" data-bs-dismiss="offcanvas"
                    aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                
                <div class="tw-mb-3">
                    <div class="tw-flex tw-justify-between">
                        <label for="first_name" class="form-label">First Name</label>
                        <span class="tw-font-bold" x-show="!isEditing" x-text="currentUser?.first_name"></span>
                    </div>
                    <div x-show="isEditing" class="tw-max-w-80">
                        <input type="text" class="form-control" :class="0 ? 'is-invalid' : 'is-valid'"
                            id="validationServer01" :value="currentUser?.first_name" disabled>
                    </div>
                </div>
                
                <div class="tw-mb-3">
                    <div class="tw-flex tw-justify-between">
                        <label for="last_name" class="form-label">Last Name</label>
                        <span class="tw-font-bold" x-show="!isEditing" x-text="currentUser?.last_name"></span>
                    </div>
                    <div x-show="isEditing" class="tw-max-w-80">
                        <input type="text" class="form-control" :class="0 ? 'is-invalid' : 'is-valid'"
                            id="validationServer01" :value="currentUser?.last_name" disabled>
                    </div>
                </div>
                
                <div class="tw-mb-3">
                    <div class="tw-flex tw-justify-between">
                        <label for="email" class="form-label">Email</label>
                        <span class="tw-font-bold" x-show="!isEditing" x-text="currentUser?.email"></span>
                    </div>
                    <div x-show="isEditing" class="tw-max-w-80">
                        <input type="text" class="form-control" :class="0 ? 'is-invalid' : 'is-valid'"
                            id="validationServer01" :value="currentUser?.email" disabled>
                    </div>
                </div>
                
                <div class="tw-mb-3">
                    <div class="tw-flex tw-justify-between">
                        <label for="tel" class="form-label">Phone No.</label>
                        <span class="tw-font-bold" x-show="!isEditing" x-text="currentUser?.tel"></span>
                    </div>
                    <div x-show="isEditing" class="tw-max-w-80">
                        <input type="text" class="form-control" :class="0 ? 'is-invalid' : 'is-valid'"
                            id="validationServer01" :value="currentUser?.tel" disabled>
                    </div>
                </div>
                
                <div class="tw-mb-3">
                    <div class="tw-flex tw-justify-between">
                        <label for="tel" class="form-label">User Role</label>
                        <span class="tw-font-bold" x-show="!isEditing" x-text="userRole"></span>
                    </div>
                    <div x-show="isEditing" class="tw-max-w-80">
                        <select class="form-select" x-model="userForm.role_id" name="role"
                            aria-label="Select user role">
                            <option value="" selected>No role</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                
                <div x-show="isEditing" class="mb-3 text-center">
                    <button @click="updateUser()" class="btn btn-primary">
                        <span x-show="loading" class="spinner-border spinner-border-sm" aria-hidden="true"></span>
                        Assign Role
                    </button>
                </div>
                
                <div x-show="!isEditing" class="alert alert-info" role="alert">
                    Click the close ( X ) button above to reload users data.
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('bs-toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
            document.addEventListener('alpine:init', () => {
                // bootstrap toast
                const toastTrigger = document.getElementById('liveToastBtn');
                const toastLiveExample = document.getElementById('liveToast');
                if (toastTrigger) {
                    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample)
                    toastTrigger.addEventListener('click', () => {
                        toastBootstrap.show();
                    })
                }

                Alpine.data('users', () => ({
                    loading: false,
                    isEditing: false,
                    users: <?php echo e(Js::from($users)); ?>,
                    currentUser: null,
                    userForm: {
                        user_id: null,
                        role_id: null,
                    },
                    toastMessage: 'Hail Christ',

                    async init() {
                        console.log(this.users.data.length);
                    },

                    // GETTERS
                    get userFullName() {
                        let name = this.currentUser?.first_name;
                        name += this.currentUser?.last_name ? ` ${this.currentUser?.last_name}` : '';
                        return name;
                    },
                    get userRole() {
                        return this.currentUser?.roles.length ? this.currentUser?.roles[0].name :
                            'No role';
                    },

                    // METHODS
                    async edit(userID) {
                        this.currentUser = this.users.data.find(user => user.id == userID);
                        if (this.currentUser.roles.length) {
                            console.log('user has role');
                            this.userForm.role_id = this.currentUser.roles[0].id;
                        } else {
                            // reset it to null
                            this.userForm.role_id = null;
                        }
                        this.userForm.user_id = this.currentUser.id;
                        this.isEditing = true;
                    },
                    reloadPage() {
                        location.reload();
                    },
                    selectImage() {
                        if (this.isEditing)
                            this.$refs.avatar.click()
                    },
                    async updateUser() {
                        this.loading = true;
                        this.userForm['_method'] = 'put';
                        try {
                            const {
                                data
                            } = await axios.post('/admin/users/' + this.userForm.id, this.userForm);
                            // this.user = data.data;
                            console.log(data);
                            this.toastMessage = data.message;
                        } catch (error) {
                            console.log('error updating user profile:', error);
                            this.toastMessage = "Error updating profile";
                        } finally {
                            this.loading = this.isEditing = false;
                            toastTrigger.click();
                        }
                    },
                }));
            });
        </script>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal951024bfcf58033c82ac11d797616473)): ?>
<?php $attributes = $__attributesOriginal951024bfcf58033c82ac11d797616473; ?>
<?php unset($__attributesOriginal951024bfcf58033c82ac11d797616473); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal951024bfcf58033c82ac11d797616473)): ?>
<?php $component = $__componentOriginal951024bfcf58033c82ac11d797616473; ?>
<?php unset($__componentOriginal951024bfcf58033c82ac11d797616473); ?>
<?php endif; ?>
<?php /**PATH C:\dev\xampp\htdocs\donzoby.com\donzoby.com\resources\views/admin/users.blade.php ENDPATH**/ ?>