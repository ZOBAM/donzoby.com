<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['posts' => $posts,'listedSubjects' => $listed_subjects,'description' => $description,'title' => $title,'pageImage' => $page_image,'customStyle' => 'home'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="home" class="tw-mt-4">
        <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_slug => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $course = $data[0]->subject->course;
                $subjects = $course->subjects;
            ?>
            <div class="card tw-mb-24 tw-pb-2">
                <div class="card-header">
                    <h1 class="card-title "><a href="<?php echo e(url('/front-end/')); ?>">
                            <?php echo e($course->name); ?></a>
                    </h1>
                </div>
                <div class="card-body">
                    <?php if($course->long_description): ?>
                        <?php echo $course->long_description; ?>

                    <?php else: ?>
                        <p class="card-text">
                            <?php echo $course->description; ?>

                        </p>
                    <?php endif; ?>
                    <div
                        class="post-links tw-flex tw-flex-col md:tw-flex-row tw-justify-around tw-items-center tw-p-4 tw-mt-8">
                        <div class="posts tw-px-6 tw-py-8 tw-rounded-2xl tw-shadow-xl">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('/' . $post->subject->course->slug . '/' . $post->subject->slug . '/' . $post->slug)); ?>"
                                    class=""><?php echo e($post->topic); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="buttons tw-px-6 tw-py-8">
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(url('/' . $subject->course->slug . '/' . $subject->slug)); ?>" class=""
                                    style="padding: 0px">
                                    <button class="">Learn <?php echo e($subject->name); ?></button>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="tw-px-4 -tw-mt-4">
                    
                    <div class="card-links tw-flex tw-justify-between tw-text-sm">
                        <span class="tw-text-gray-500">Latest: </span>
                        <span class=""><a
                                href="<?php echo e(url('/' . $latest_modified[$course_slug]->subject->course->slug . '/' . $latest_modified[$course_slug]->subject->slug . '/' . $latest_modified[$course_slug]->slug)); ?>"><?php echo e($latest_modified[$course_slug]->topic); ?></a>
                            <span class="tw-text-xs">
                                &#9001;updated
                                <?php echo e(date('M d, Y', strtotime($latest_modified[$course_slug]->updated_at))); ?>&#x3009;
                            </span> </span>
                    </div>
                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\dev\xampp\htdocs\donzoby.com\donzoby.com\resources\views/dzb.blade.php ENDPATH**/ ?>