<x-single_col title="Mission & Vision">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" id="donzoby-info">
                <div class="card-body">
                    <h1>Our Mission @Donzoby</h1>
                    <p>
                        To educate and equip the elects with needed computer knowledge for effective service to God and
                        humanity in this age of ICT.
                    </p>
                    <p>
                        In seeking to realize the above mission, we are engaging all mechanisms and instruments of
                        learning and simplification of learning to bridge that gap between what you know and what you
                        are supposed to know with regard to relevant computer skills that your need for efficiency in
                        your daily work and live.
                    </p>
                    <h2 class="text-center">Our Vision @Donzoby</h2>
                    <p> Simplify the process of acquiring and transferring computer knowledge and solutions for the
                        Elect pilgrims, and then the entire world in a God-conscious manner.
                    </p>
                </div>
            </div>
        </div>
    </div>
</x-single_col>
