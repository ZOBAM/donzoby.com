<div class='container-fluid' id='main-content'>
    <div class = "col-lg-7" id="center-col">
        <!-- <h1>Welcome to DTech where we do tech with conscience!</h1> -->






    </div> <!-- ------------------------------ ends center column ------------------------------- -->
