<template>
  <v-app>
    <v-main>
      <Dashboard />
    </v-main>
  </v-app>
</template>

<script setup>
// import HelloWorld from '@/components/HelloWorld.vue'
import Dashboard from '@/views/dashboard.vue'
</script>
