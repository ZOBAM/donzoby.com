<template>
    <article fluid>
        <v-container fluid class="fill-height">
            <v-row>
                <v-col cols="2 left-nav">
                    <div><img src="../assets/images/logo.png" alt=""></div>
                    <ul>
                        <li v-for="(item, i) in navLinks" :key="i">
                            <img :src="getImage(`../assets/images/icon_${item.icon}.svg`)" alt="">
                            <span>{{ item.text }}</span>
                        </li>
                    </ul>
                </v-col>
                <v-col cols="10">
                    <header class="d-flex justify-space-between">
                        <div class="left-group d-flex align-center">
                            <v-icon icon="mdi-menu" style="display: inline-block; margin: 0px 1rem"></v-icon>
                            <v-icon icon="mdi-search"></v-icon>
                            <input type="text" name="search" id="search" placeholder="Enter a keyword">
                        </div>
                        <div class="right-group d-flex align-center">
                            <img src="../assets/images/icon_mail.svg" alt="">
                            <img src="@/assets/images/icon_bell.svg" alt=""
                                style="display: inline-block; margin: 0px 2rem">
                            <img src="../assets/images/admin.png" alt="">
                            <p style="display: inline-block; margin: 0px .5rem; font-size: 16px;">
                                <span class="">Hi, </span><span style="color: #666666;">Oluwatosin K</span>
                            </p>
                            <img src="../assets/images/icon_caret-down.svg" alt="">
                        </div>
                    </header>
                    <section class="content-area">
                        <h1>Dashboard</h1>
                        <v-row>
                            <v-col class="left-content col-sm-8">
                                <div class="top-data-group">
                                    <div class="">
                                        <h6>Info</h6>
                                        <p>123.45</p>
                                        <span>coming soon</span>
                                    </div>
                                    <div class="">
                                        <h6>Info</h6>
                                        <p>623.45</p>
                                        <span>coming soon</span>
                                    </div>
                                    <div class="">
                                        <h6>Info</h6>
                                        <p>123.45</p>
                                        <span>coming soon</span>
                                    </div>
                                    <div class="">
                                        <h6>Info</h6>
                                        <p>123.45</p>
                                        <span>coming soon</span>
                                    </div>
                                </div>
                                <div class="bar-chart">
                                    <bar-chart />
                                </div>
                                <div class="line-chart">
                                    <line-chart />
                                </div>
                            </v-col>
                            <v-col sm="4" class="right-content col-sm-4">
                                <div class="pie-chart">
                                    <pie-chart />
                                </div>
                                <div class="notifications">
                                    <div class="heading">
                                        <span>Notifications</span>
                                        <button>
                                            <span>Clear</span>
                                            <span>
                                                <img src="../assets/images/icon_times.svg" alt="times icon">
                                            </span>
                                        </button>
                                    </div>
                                    <ul>
                                        <li v-for="(item, index) in notifications" :key="index">
                                            <img src="../assets/images/receipt.svg" alt="">
                                            <span>
                                                {{ item.text }}
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </v-col>
                        </v-row>

                    </section>
                </v-col>
            </v-row>
        </v-container>
    </article>
</template>
<script>
import BarChart from '@/components/BarChart.vue';
import LineChart from '@/components/LineChart.vue';
import PieChart from '@/components/PieChart.vue';

export default {
    components: { BarChart, LineChart, PieChart },
    data() {
        return {
            navLinks: [
                { text: 'Dashboard', icon: 'dashboard' },
                { text: 'Schools', icon: 'schools' },
                { text: 'Students', icon: 'students' },
                { text: 'Parents', icon: 'parents' },
                { text: 'Teachers', icon: 'teachers' },
                { text: 'Reports', icon: 'reports' },
                { text: 'Subscriptions', icon: 'subscriptions' },
                { text: 'Tickets', icon: 'tickets' },
                { text: 'Settings', icon: 'settings' },
                { text: 'Log Out', icon: 'logout' },
            ],
            notifications: [
                { text: 'You have a new ticket from Atlantic Hall College', icon: 'tickets' },
                { text: 'You have a new ticket from Atlantic Hall College', icon: 'students' },
                { text: 'You have a new ticket from Atlantic Hall College', icon: 'teachers' },
                { text: 'You have a new ticket from Atlantic Hall College', icon: 'reports' },
                { text: 'You have a new ticket from Atlantic Hall College', icon: 'subscriptions' },
            ]
        }
    },
    methods: {
        getImage(imagePath) {
            // return require(imagePath);
            return new URL(imagePath, import.meta.url).href;
        }
    },
}
</script>

<style lang="scss" scoped>
.left-nav {
    background: #FFFFFF;
    box-shadow: 0px 4px 20px rgba(56, 59, 76, 0.25);

    div {
        text-align: center;

        img {
            max-width: 100%;
        }
    }

    ul {
        list-style-type: none;

        li {
            padding: 1rem .8rem;
            display: flex;
            align-items: center;
            column-gap: .9rem;
            color: #666666;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;

            img {
                min-width: 20px;
            }
        }
    }
}

header {
    height: 92px;
    background-color: #fff;
    box-shadow: 0px 4px 20px rgba(56, 59, 76, 0.25);

    div.left-group {

        input {
            border-radius: 6px;
            padding: .5rem;
            width: 28rem;
            box-shadow: 0px 7px 64px rgba(0, 0, 0, 0.07);
            background: #FFFFFF;
        }
    }

    div.right-group {
        p {
            span {
                color: grey;
            }
        }
    }
}

//header

.content-area {
    background-color: #EFF1F9;
    padding: 1rem;

    .left-content {
        padding: 1.5rem;

        div.top-data-group {
            display: flex;
            justify-content: space-between;

            div {
                background-color: white;
                padding: .9rem;
                width: 23%;
                box-shadow: 0px 0.5px 1.75px rgba(0, 0, 0, 0.039), 0px 1.85px 6.25px rgba(0, 0, 0, 0.19);
                border-radius: 4px;

                h6 {
                    color: rgba(0, 0, 0, 0.6);
                }

                p {
                    font-size: 34px;
                    margin-bottom: 0rem;
                    padding-bottom: 0rem;
                    line-height: 1.9rem;
                }

                span {
                    color: #43A047;
                    font-size: 14px;
                }
            }
        }

        // div.top-data-group
        div.bar-chart,
        div.line-chart {
            margin-top: 2rem;
            background-color: #fff;
            padding: 1rem;
            box-sizing: content-box;
            max-width: 100%;
            box-shadow: 0px 0.5px 1.75px rgba(0, 0, 0, 0.039), 0px 1.85px 6.25px rgba(0, 0, 0, 0.19);
        }
    }

    // .left-content
    div.right-content {

        div.pie-chart {
            background-color: white;
            padding: 1rem;
            box-shadow: 0px 0.5px 1.75px rgba(0, 0, 0, 0.039), 0px 1.85px 6.25px rgba(0, 0, 0, 0.19);
        }

        div.notifications {
            background-color: #fff;
            margin-top: 2rem;
            box-shadow: 0px 0.5px 1.75px rgba(0, 0, 0, 0.039), 0px 1.85px 6.25px rgba(0, 0, 0, 0.19);

            div,
            li {
                padding: 1.3rem;
            }

            div.heading {
                display: flex;
                justify-content: space-between;
                align-items: center;

                span {
                    // font-size: 18px;
                    font-weight: 400;
                }

                button {
                    display: flex;
                    color: #B00020;
                    column-gap: 1rem;
                    border: 2px solid #B00020;
                    filter: drop-shadow(0px 4px 20px rgba(56, 59, 76, 0.25));
                    border-radius: 10px;
                    padding: .5rem 1rem;
                    text-transform: uppercase;
                    font-size: 14px;
                }
            }

            ul {
                list-style-type: none;

                li {
                    border-top: 1px dotted #00000033;
                    border-bottom: 1px dotted #00000033;
                    font-size: 12px;
                    display: flex;
                    align-items: center;
                    column-gap: .4rem;

                    img {
                        fill: red;
                        stroke: red;
                        transition: all 0.3s linear;
                    }
                }
            }
        }
    }
}
</style>